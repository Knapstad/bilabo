cloud_credentials = "bilabo-4346783febd2.json"

projectname = "bilabo"

bucket_name = "bilabo"

text_blob_name = "mycars.json"
